import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import "./App.css";

const App = () => {
  // App State Management
  const [currentView, setCurrentView] = useState('dashboard'); // dashboard, checkin, chat, resources
  const [userMood, setUserMood] = useState('neutral');
  const [chatMessages, setChatMessages] = useState([
    {
      id: 1,
      text: "Hi there! I'm Sage, your campus support guide. How are you feeling today?",
      sender: 'bot'
    }
  ]);
  const [userInput, setUserInput] = useState('');
  const [wellnessData, setWellnessData] = useState([
    { day: 'Mon', mood: 3, sleep: 7, activity: 5 },
    { day: 'Tue', mood: 4, sleep: 6, activity: 6 },
    { day: 'Wed', mood: 2, sleep: 5, activity: 4 },
    { day: 'Thu', mood: 3, sleep: 7, activity: 5 },
    { day: 'Fri', mood: 5, sleep: 8, activity: 7 },
    { day: 'Sat', mood: 4, sleep: 9, activity: 8 },
    { day: 'Sun', mood: 3, sleep: 7, activity: 6 }
  ]);

  // Handle sending a message in the chat
  const handleSendMessage = () => {
    if (!userInput.trim()) return;
    
    // Add user message
    const newUserMessage = {
      id: Date.now(),
      text: userInput,
      sender: 'user'
    };
    
    setChatMessages(prev => [...prev, newUserMessage]);
    setUserInput('');
    
    // Simulate AI bot response after a short delay
    setTimeout(() => {
      const botResponses = [
        "I hear you. It's completely normal to feel that way, especially with academic pressures.",
        "Thank you for sharing. Would you like to try a quick breathing exercise to help center yourself?",
        "I understand. Remember to be kind to yourself. How has your sleep been lately?",
        "It sounds like you're going through a lot. Would it help to talk about what's specifically on your mind?",
        "I'm here for you. Sometimes taking a short walk or listening to music can help shift our perspective."
      ];
      
      const randomResponse = botResponses[Math.floor(Math.random() * botResponses.length)];
      
      const botMessage = {
        id: Date.now() + 1,
        text: randomResponse,
        sender: 'bot'
      };
      
      setChatMessages(prev => [...prev, botMessage]);
    }, 1000);
  };

  // Handle mood selection in the check-in
  const handleMoodSelect = (mood) => {
    setUserMood(mood);
    
    // Simulate saving the check-in and showing confirmation
    setTimeout(() => {
      alert(`Thanks for checking in! Your ${mood} mood has been recorded.`);
      setCurrentView('dashboard');
      
      // Update wellness data with new entry (simplified)
      const newData = [...wellnessData];
      newData[6].mood = 
        mood === 'excited' ? 5 : 
        mood === 'happy' ? 4 : 
        mood === 'neutral' ? 3 : 
        mood === 'sad' ? 2 : 1;
      
      setWellnessData(newData);
    }, 500);
  };

  // Navigation component
  const Navigation = () => (
    <nav className="bg-white shadow-sm rounded-lg mb-6">
      <div className="flex space-x-1 p-2">
        {['dashboard', 'checkin', 'chat', 'resources'].map((item) => (
          <button
            key={item}
            onClick={() => setCurrentView(item)}
            className={`flex-1 py-3 px-4 rounded-md text-sm font-medium transition-all duration-200 ${
              currentView === item
                ? 'bg-blue-100 text-blue-700 shadow-inner'
                : 'text-gray-600 hover:text-blue-600 hover:bg-gray-50'
            }`}
          >
            {item.charAt(0).toUpperCase() + item.slice(1)}
          </button>
        ))}
      </div>
    </nav>
  );

  // Dashboard View
  const DashboardView = () => (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="space-y-6"
    >
      <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-6 rounded-2xl">
        <h2 className="text-xl font-semibold text-gray-800 mb-2">Welcome Back!</h2>
        <p className="text-gray-600">Here's your wellness overview for the week.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100">
          <h3 className="font-medium text-gray-700 mb-2">Average Mood</h3>
          <div className="text-2xl font-bold text-blue-600">3.4/5</div>
          <div className="text-sm text-gray-500">Similar to last week</div>
        </div>
        
        <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100">
          <h3 className="font-medium text-gray-700 mb-2">Sleep Quality</h3>
          <div className="text-2xl font-bold text-green-600">6.8h avg</div>
          <div className="text-sm text-gray-500">+0.5h from last week</div>
        </div>
        
        <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100">
          <h3 className="font-medium text-gray-700 mb-2">Activity Level</h3>
          <div className="text-2xl font-bold text-orange-600">5.7/10</div>
          <div className="text-sm text-gray-500">Keep it up!</div>
        </div>
      </div>

      <div className="bg-white p-6 rounded-2xl shadow-sm">
        <h3 className="font-semibold text-gray-800 mb-4">Weekly Wellness Trends</h3>
        <div className="h-48 flex items-end space-x-2">
          {wellnessData.map((day, index) => (
            <div key={day.day} className="flex-1 flex flex-col items-center">
              <div className="text-xs text-gray-500 mb-2">{day.day}</div>
              <div className="w-full flex justify-center space-x-1">
                <div 
                  className="w-3 bg-blue-200 rounded-t transition-all duration-300 hover:bg-blue-300"
                  style={{ height: `${day.mood * 15}px` }}
                  title={`Mood: ${day.mood}/5`}
                />
                <div 
                  className="w-3 bg-green-200 rounded-t transition-all duration-300 hover:bg-green-300"
                  style={{ height: `${day.sleep * 5}px` }}
                  title={`Sleep: ${day.sleep}h`}
                />
                <div 
                  className="w-3 bg-orange-200 rounded-t transition-all duration-300 hover:bg-orange-300"
                  style={{ height: `${day.activity * 8}px` }}
                  title={`Activity: ${day.activity}/10`}
                />
              </div>
            </div>
          ))}
        </div>
        <div className="flex justify-center space-x-4 mt-4">
          <div className="flex items-center">
            <div className="w-3 h-3 bg-blue-200 rounded mr-2"></div>
            <span className="text-xs text-gray-600">Mood</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 bg-green-200 rounded mr-2"></div>
            <span className="text-xs text-gray-600">Sleep</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 bg-orange-200 rounded mr-2"></div>
            <span className="text-xs text-gray-600">Activity</span>
          </div>
        </div>
      </div>

      <button 
        onClick={() => setCurrentView('checkin')}
        className="w-full py-4 bg-blue-600 text-white rounded-2xl font-medium hover:bg-blue-700 transition-colors duration-200 shadow-md"
      >
        Complete Today's Check-in
      </button>
    </motion.div>
  );

  // Check-in View
  const CheckinView = () => (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="space-y-6"
    >
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-800 mb-2">Daily Check-in</h2>
        <p className="text-gray-600">How are you feeling today?</p>
      </div>

      <div className="grid grid-cols-2 gap-4">
        {[
          { mood: 'excited', label: 'Excited', emoji: '😄', color: 'bg-green-100 text-green-800' },
          { mood: 'happy', label: 'Happy', emoji: '😊', color: 'bg-blue-100 text-blue-800' },
          { mood: 'neutral', label: 'Neutral', emoji: '😐', color: 'bg-yellow-100 text-yellow-800' },
          { mood: 'sad', label: 'Sad', emoji: '😔', color: 'bg-purple-100 text-purple-800' },
          { mood: 'anxious', label: 'Anxious', emoji: '😰', color: 'bg-red-100 text-red-800' },
          { mood: 'tired', label: 'Tired', emoji: '😴', color: 'bg-gray-100 text-gray-800' }
        ].map(({ mood, label, emoji, color }) => (
          <motion.button
            key={mood}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => handleMoodSelect(mood)}
            className={`p-6 rounded-2xl text-center transition-all duration-200 ${color} ${
              userMood === mood ? 'ring-2 ring-offset-2 ring-current' : ''
            }`}
          >
            <div className="text-3xl mb-2">{emoji}</div>
            <div className="font-medium">{label}</div>
          </motion.button>
        ))}
      </div>

      <div className="bg-white p-6 rounded-2xl shadow-sm">
        <h3 className="font-semibold text-gray-800 mb-4">Quick Questions</h3>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              How many hours did you sleep last night?
            </label>
            <select className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
              {[4,5,6,7,8,9,10].map(hours => (
                <option key={hours} value={hours}>{hours} hours</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Stress level today (1-10):
            </label>
            <input 
              type="range" 
              min="1" 
              max="10" 
              defaultValue="5"
              className="w-full"
            />
            <div className="flex justify-between text-xs text-gray-500">
              <span>Low</span>
              <span>High</span>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );

  // Chat View
  const ChatView = () => (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="flex flex-col h-96"
    >
      <div className="flex-1 overflow-y-auto space-y-4 mb-4 p-2">
        {chatMessages.map((message) => (
          <motion.div
            key={message.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-xs lg:max-w-md p-4 rounded-2xl ${
                message.sender === 'user'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-800'
              }`}
            >
              {message.text}
            </div>
          </motion.div>
        ))}
      </div>
      
      <div className="flex space-x-2">
        <input
          type="text"
          value={userInput}
          onChange={(e) => setUserInput(e.target.value)}
          onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
          placeholder="Type your message..."
          className="flex-1 p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
        />
        <button
          onClick={handleSendMessage}
          className="px-6 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors"
        >
          Send
        </button>
      </div>
    </motion.div>
  );

  // Resources View
  const ResourcesView = () => (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="space-y-4"
    >
      <h2 className="text-2xl font-bold text-gray-800 mb-4">Campus Resources</h2>
      
      {[
        {
          title: "Counseling Center",
          description: "Professional mental health support available on campus",
          contact: "555-0123 | counseling@campus.edu"
        },
        {
          title: "Crisis Hotline",
          description: "24/7 support for immediate mental health concerns",
          contact: "988 | Available anytime"
        },
        {
          title: "Health Services",
          description: "Medical care and wellness consultations",
          contact: "555-0456 | health@campus.edu"
        },
        {
          title: "Academic Support",
          description: "Tutoring and study skills assistance",
          contact: "555-0789 | academic@campus.edu"
        }
      ].map((resource, index) => (
        <motion.div
          key={index}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1 }}
          className="bg-white p-5 rounded-2xl shadow-sm border border-gray-100"
        >
          <h3 className="font-semibold text-gray-800 mb-2">{resource.title}</h3>
          <p className="text-gray-600 mb-3">{resource.description}</p>
          <p className="text-sm text-blue-600 font-medium">{resource.contact}</p>
        </motion.div>
      ))}
      
      <div className="bg-blue-50 p-5 rounded-2xl mt-6">
        <h3 className="font-semibold text-gray-800 mb-2">Self-Help Tools</h3>
        <div className="grid grid-cols-2 gap-3">
          <button className="p-3 bg-white rounded-lg text-sm font-medium hover:bg-blue-100 transition-colors">
            Breathing Exercise
          </button>
          <button className="p-3 bg-white rounded-lg text-sm font-medium hover:bg-blue-100 transition-colors">
            Meditation Guide
          </button>
          <button className="p-3 bg-white rounded-lg text-sm font-medium hover:bg-blue-100 transition-colors">
            Sleep Sounds
          </button>
          <button className="p-3 bg-white rounded-lg text-sm font-medium hover:bg-blue-100 transition-colors">
            Study Break Ideas
          </button>
        </div>
      </div>
    </motion.div>
  );

  // Render the appropriate view
  const renderCurrentView = () => {
    switch (currentView) {
      case 'checkin':
        return <CheckinView />;
      case 'chat':
        return <ChatView />;
      case 'resources':
        return <ResourcesView />;
      default:
        return <DashboardView />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-md mx-auto bg-white rounded-3xl shadow-xl p-6 min-h-96">
        {/* App Header */}
        <div className="text-center mb-6">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", stiffness: 200 }}
            className="w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-3"
          >
            <img 
              src="https://placeholder-image-service.onrender.com/image/48x48?prompt=calm%20mind%20icon%20with%20leaf%20and%20brain%20silhouette&id=7c2e5a1b-3d8f-4a7c-9b2d-6e3f4a5b6c7d" 
              alt="MindSync app logo featuring a serene brain and leaf symbol representing mental wellness"
              className="w-8 h-8"
            />
          </motion.div>
          <h1 className="text-2xl font-bold text-gray-800">MindSync Campus</h1>
          <p className="text-gray-600">Your mental wellness companion</p>
        </div>

        {/* Navigation */}
        <Navigation />
        
        {/* Main Content */}
        <AnimatePresence mode="wait">
          {renderCurrentView()}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default App;